# How to use this Notebook
- Download or Pull the notebook from github
- Copy the train.csv and test.csv files in the same directory as your notebook and run the notebook on either jupyter lab, jupyter notebook or Google Colab.
- Feel free to point out any mistakes and explore the data in your own way.
- And if you need any help understanding the code just reach out on slack.
- **train.csv** file was too big to upload on github just use this [link](https://www.notion.so/76f757ab85ae4d9c9666bd4fbd626032?v=b852dec5cc684da8874b5d61ae1add14) to get the data 

# Data Insight
The common steps for data insight are:
- Check the shape(no of rows and columns) of the dataset
- Take a look at the head and tail of the data to understand different features and observations
- Check for the data types of every feature, total no of observations, no of null values present in every feature
- Check for naming convention of each feature
- Check for invalid datatypes
- Check for data validity and data accuracy
- Take a look at the descriptive statistics(mean,median, Standard deviation, minimum, maximum, 25%(Q1),50%(Q2),75%(Q3)) of the dataset
- Check for duplicate entries  in the dataset and remove them
- Check and summarize the no of unique values for each feature. It will give insight about the visualization of data distribution for numerical and categorical data.
 

# Data Preprocessing
Data preprocessing is the process of converting the raw data into usable format. This involves data cleaning, data transformation and data normalization.
The performance of a machine learning model is determined not only by the model and hyperparameters, but also on how we process & feed different types of variables to the model that’s why it become necessary step to preprocess the data

# Tasks performed for Data Preprocessing are as follows -:
1. Get Data Insights
2. Handling Missing values for all features
3. Outliers Detection
4. Determining & visualising Categorical - Features
5. Types of categorical features
6. Masking Data
7. Grouping Data
8. Data Encoding & the approach taken for Encoding 

## Handling missing values
The imputation techniques that we used for handling the null values are as follows:

### 1. KNN Imputation
This imputer replaces missing values in datasets with the mean value from the parameter 'n_neighbors,' nearest neighbours found in the training set using the k-Nearest Neighbors algorithm. It imputes missing values using a Euclidean distance metric by default.

### 2. Sci-Kit Learn SimpleImputer
This is a class provided by Scikit-Learn to take care of missing values. We need to create a SimpleImputer instance specifying the strategy to replace the missing values.
There are four different strategies that can be used in this imputation technique.
 - “mean”          - replace missing values using the mean along each column. Can only be used with numeric data.
 - “median”        - replace missing values using the median along each column. Can only be used with numeric data.
 - “most_frequent” - replace missing using the most frequent value along each column. Can be used with strings or numeric data. If there is more than one such value, only the smallest is returned.
 - “constant”       - replace missing values with fill_value. Can be used with strings or numeric data.

## Visualization of missing values
We used missingno library to understand the pattern of missing values.

![Alt text](/src/visualizations/task_1_pre_processing/missing_values.png) 

The below table shows the percentage of missing values in our dataset.

![Alt text](/src/visualizations/task_1_pre_processing/percent_missing.png) 

Following are the methods implemented to handle null values in our dataset

-	year_built column has 2.4% null values. KNN imputer is used to impute this column. We can also drop all the missing rows if necessary.
- energy_star_rating column is imputed using KNN imputer.
-	direction_max_wind_speed, direction_peak_wind_speed, max_wind_speed have above 50% of missing values and they have missing values on the same days. This might be because of system malfunction or device error. For imputing these values Scikit learn’s simple imputer with “most frequent” strategy is used. 
-	days_with_fog colum is imputed with most frequent value. It can also be imputed with zero.


## Outlier Detection:
Outlier is an observation that is significantly different from the rest of the observations. There are few ways we can detect outliers.
- Standard deviation method
- Interquartile Range(IQR)  
- percentile based approach 

IQR based filtering is used for detecting outliers since our data is skewed. More detailed analysis on outliers are done in EDA section.

Determining & visualising Categorical-Features

Following are the Categorical Columns present in our dataset which needs to be converted into Numerical
"State_Factor" - This feature has 7 unique values( State1,state 2,state 4,state 6,state 8,state 10,state 11)
"building_class" - This feature has 2 unique values (Commercial,Residential)
"facility_type" - This feature has 60 unique values (food, warehouse, retail, education, office, commercial, Industrial, public_assembly, lodging, Religious_worship, healthcare, Nursing_Home, Multifamily, public_safety etc.)
Visual representation of Categorical features :

# Determining & visualising Categorical-Features

Following are the Categorical Columns present in our dataset which needs to be converted into Numerical
 1. "State_Factor" - This feature has 7 unique values( State1,state 2,state 4,state 6,state 8,state 10,state 11)
 2. "building_class" - This feature has 2 unique values (Commercial,Residential)
 3. "facility_type" - This feature has 60 unique values (food, warehouse, retail, education, office, commercial, Industrial, public_assembly, lodging,     Religious_worship, healthcare, Nursing_Home, Multifamily, public_safety etc.)

  # Visual representation of Categorical features :
  
  ![image](https://user-images.githubusercontent.com/80121041/176824906-78546c97-6a6a-49c7-b04c-058925be5332.png)
  ![image](https://user-images.githubusercontent.com/80121041/176824964-32983988-18ad-46f6-892b-2bd3b7cc8286.png)
  ![image](https://user-images.githubusercontent.com/80121041/176824749-92bc1b25-b9b6-43d0-a2b0-f52483de88c1.png)


  
# Types of categorical features :
Two types of categorical features exist
Ordinal Features
Nominal Features

  1. Ordinal Features:
Ordinal features are the features that have inherent ordering.
Eg: Ratings such as Good, Bad, Worse.

  2. Nominal Features:
Nominal features are the features that don’t have any inherent ordering as opposed to Ordinal features.
Eg: Names of persons, gender, yes, or no.

# Masking Data
We are using str.contains to mask the rows that contain a specific string and then overwrite with the new value:

(str.contains :- Return boolean Series or Index based on whether a given pattern or regex is contained within a string of a Series or Index.)

As we can see that we have 60 categories praesent in the “Facility_type” column. Removing duplicate features and features which are very similar to others in the data frame becomes a very necessary step. There might be cases where the features in the dataset are either duplicated or very similar. After Masking “Facility_Type” column of the dataset we are left with 14 categories in this column which is a considerable drop from 60 we had in the beginning to 14 categories.

# Grouping
There are 2 ways to group the data column 'facility_type'
--Only use the top 10
--grouping similar features
During the teams discussions we are going to group these categories by the following:
Multifamily_Uncategorized
Office_Uncategorized
Educational_Other_classroom
Lodging_Hotel
Other
After grouping we are able to reduce the category type further from 14 to 8.
![image](https://user-images.githubusercontent.com/80121041/176825081-4e9f3004-0b41-4b91-80df-ef7674b437f1.png)


# Data Encoding & the approach taken for Encoding :

Encoding is a technique of converting categorical variables into numerical values so that it can be easily fitted to a machine learning model as Machine Learning models accept numerical values. It  helps in better Feature Engineering and also performance of ML algorithms is based on how Categorical variables are encoded. The results produced by the model vary from different encoding techniques used.

There are many ways we can encode categorical variables
1) Label Encoding or Ordinal Encoding 
2) One hot Encoding 
3) Dummy Encoding 
4) Effect Encoding 5) Binary Encoding 
6) BaseN Encoding 
7) Hash Encoding
 8) Target Encoding
we will not use Label Encoding in our case as Label encoding is used for ordinal data. The data within our dataset categorical features ("State_Factor","building_class","facility_type") are nominal which means they don't contain any inherent ordering. 
 
we will be using here Dummy Encoding , One Hot Encoding & may be Binary Encoding if needed.
As the "building_class" only has 2 unique values we can use the Pandas get_dummies() function. This will create a binary variable for "Commerical" and "Residential” as can be seen in below diagram.

![image](https://user-images.githubusercontent.com/80121041/176824157-919796b0-8a43-467d-bce6-aef1e3539391.png)


Now we are using one hot encoder to encode the Categorical columns 'facility_type','State_Factor'. 
Each bit represents a possible category. If the variable cannot belong to multiple categories at once, then only one bit in the group can be “on.” This is called one-hot encoding . In the diagram below we are able to encode Facility type data using One Hot Encoding likewise we did for “State_Factor”

![image](https://user-images.githubusercontent.com/80121041/176824051-41b90eab-2498-4bdd-8b8e-76b545e6690b.png)


