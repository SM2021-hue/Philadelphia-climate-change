# Exploratory Data Analysis (EDA)

Exploratory Data Analysis, the purpose of this task is to get in-depth knowledge of whole dataset so that effective manipulation can be done for our machine learning model. EDA helps in understanding each features by finding hidden patterns, outliers, relationships and also unfolds the important features from the dataset.

# Tasks performed
## Sub-tasks performed in EDA technique are as follows -:
1) Basic analysis of dataset
2) Descriptive Analysis
3) Uni-Variate Analysis (Separately for both Categorical and Numerical features)
4) Bi-Variate Analysis (Correlation Matrix)
5) Hypothesis Testing ( Not valid with this dataset as data is skewed not normally distributed, done for sake of knowledge)
    * Z-Test: Parametric Test
    * T-Test: Parametric Test
    * Chi-Square Test: Parametric Test
    * Kruskal-Wallis H-Test: Non-Parametric Test

## 1) Basic Analysis of dataset
In this section, we just skimmed the data. Process followed are -:

1.1) Shape of the data which is the total number of rows and columns (75757 * 64)

1.2) Looked for the data types and columns with null values
    * Three Categorical columns and rest Numerical (`State_Factor, building_class, facility_type`)
    * Columns with Missing values: (`year_built, energy_star_rating, direction_max_wind_speed, direction_peak_wind_speed, max_wind_speed, days_with_fog`)
    * `year_built` is in float data type, it needs to be converted into Integer as year can't be float

## 2) Descriptive Analysis
In this section, Descriptive statistical analysis had been done (Descriptive can only be performed on Numerical variables), Descriptive analysis helps in understanding the centre which is mean, meadian of the data, it also give us the overlook of shape and spread of each data point. Inferences from descriptive analysis are -:

2.1) `Year_Factor` is Numerical value in our dataset but in actual if we take a look, year_factor is actually a anonymous six different years so we can't take it as a numerical, it should be categorical and also taking it as numerical will put more weightage to year=6 rows than year=1. So we converted Year_Factor in categorical variable

2.2) `year_built` has 1 row with 0 value in it which can't be possible as year can't be zero, so converted it to np.nan

2.3) `days_below _0F`, `days_above_100F` and `days_above_110F` has most data as 0 (we might drop these columns if we don't get enough evidence that they highly relate to site_eui   in future steps)

2.4) `direction_max_wind_speed:` if you see that min, 25 percentile, 50 percentile, 75 percentile values are 1 and max value is 360, this tells us that more than 75 percentile values are 1 that means this column is not brining a lot of variability and possibly can be dropped.

2.5) `direction_peak_wind_speed:` if you see that min, 25 percentile, 50 percentile, 75 percentile values are 1 and max value is 360, this tells us that more than 75 percentile values are 1 that means this column is not brining a lot of variability and possibly can be dropped.

2.6) `days_with_fog:` we would assume that the days when there is no fog have `NaN` values and can be replaced with `0` and that would take care of the missing values in this column

2.7) `id:` seems to be index column so it can be dropped or can be set as index

2.8) We can drop missing rows from `year_built` as it has only 2.4% of missing values which is 1843 rows out of 75757 rows, dropping around 2K rows won't make any difference to our analysis and predictive model

2.9) Using our current year as benchmark, new column age has been created from `year_built` and current year `2022` (`age` = 2022 - `year_built` ) 

## Visual analysis of Missing variables (Picture)
For visualizing missing variable two methods were used -:
1) using missingno library: This library helps in understanding the pattern of missing data, it takes care of missing values by itself
2) using Plotly or Matplotlib: These are famous python visualization libraries, to understand the missing patterns using these libraries we have to tell them that we are only looking to plot rows with missing rows as True in our data (data = `df[nullcolumns].isna()`)

![missingno.matrix!](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/Missing_Pattern.png)

Inferences, missing data pattern for `direction_max_wind_speed`, `direction_peak_wind_speed`, and `max_wind_speed` are exactly similar, one reason behind this could be the error or malfunction in the device

## 3) Univariate Analysis
Univariate analysis, In this each data points analyzed individually. Graphs were plotted with statistical information to get the indepth knowledge of individual variable such as skewness, kurtosis, standard deviation, range, mean, median and IQR.

3.1) Categorical variables 
With categorical variables, count plot is the better representation of the analysis. It also helped us in reducing the size of facility type from 60 to 14 by grouping them into their respective categories ('food', 'warehouse', 'retail', 'education', 'office', 'commercial','Industrial', 'public_assembly', 'lodging', 'Religious_worship', 'healthcare','Nursing_Home', 'Multifamily', 'public_safety')

![facility_type_dimension_reduction!](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/Facility_Type_Uncategorized.png)
![facility_type_dimension_reduction!](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/Facility_Type_categorized.png)

* Skewness = Skewness is a measure of symmetry of distribution. There are three types of skewness:
    1) Right Skew = When most of the data is in left side of the graph, It is also known as positive skewness (mode < median < mean)
    2) Left Skew = When most of the data is in right side of the graph, also known as negative skewness (mean < median < mode)
    3) Zero Skew = When data is in middle of the graph (mean = median = mode)
A skewness value greater than 1 or less than -1 indicates a highly skewed distribution. A value between 0.5 and 1 or -0.5 and -1 is moderately skewed. A value between -0.5 and 0.5 indicates that the distribution is fairly symmetrical. (ref: https://docs.oracle.com/cd/E57185_01/CBREG/ch03s02s03s01.html)

* Kurtosis = Kurtosis is a measure of data being heavy or light tailed relative to normal distribution, kurtosis with greater than 3 means heavy tailed and less than 3 means light tailed and around 3 means normal distribution

* Standard deviation = Standard deviation measures the spread of data relative to mean value
* Range = Range measures the range of the data by subtracting max and min value and not a right measure as it can be easily affected because of outliers
* Mean and Median = Measures the centre value of the data (mean can be affected by outliers)
* IQR = It is the measure of the spread of the data within Q1 and Q3

3.2) While looking at the data we are also removing outliers based on IQR method
`IQR = 1.5*(df.quantile(0.75) - df.quantile(0.25))` (General formula) anything that lies outside this are outliers and we can remove those values from our data. In this project we have used `4.5*(df.quantile(0.75) - df.quantile(0.25))` as we didn't want to loose much values and also there are few big buildings which can be useful and loosing them might not give us better results with out model.

![floor_area_original](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/floor_area.png)
![floor_area_after_outliers](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/floor_area_after_outliers.png)

`4.5 is just a hit and trail number, and the reason why we stick to it as if we look at floor area distribution graph value is in million and looking at x-axis of the graph we may say if we take a number somewhere in the middle of 1 and 2 can give us better result without loosing much data`
We have also tried our hands on 3-standard deviation rule but 3-standard deviation can fail in providing better result because it can be heavily affected outliers

![Days_above_110F](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/days_above_110F.png)

`Days_above_110F` has only one value in it so it makes sense to remove the column from our dataset as it is of no help.

## 4) Bi-Variate Analysis
Bi-variate analysis, In this type of analysis we analyse two variable to determine the relaionship with each other. It give us the insight about if the two are related to each other or not.
We used Correlation matrix and scatter plot for our Bi-Variate Analysis, Using Correlation graph we can see the which variable are positively or negatively correlated with each other.

4.1) Positive Correlation: When changes in one variable is directly proportional to changes in second variable

4.2) Negative Correlation: When changes in one variable is inversely proportional to changes in second variable

4.3) No Correlation: When changes in one variable does not affect changes in another variable

Notes from Correlation graph:
* `Days_above_110F` has NAN value in it as we already discussed and we can even see that in here
* `site_eui` has strong correlation with these following variables:
    1) `floor_area`
    2) `energy_star_rating`
    3)  `age`
    4) `days_with_fog`
* Minimum and Maximum Temperature columns have high correlation with their respective months Average Temperature (we can drop min and max in future steps and keep only average temperature)

4.4) Scatter Plot:
Scatter plot is another best visual representation to understand the relation, and strength between two variables. It tells if the variable 1 has positive, negative or no relation with variable 2, and also about how strong or weak that relation is based on how steep upward and downward pattern (slope) in data. It also helps in understanding about the form or spread of data with each other  

![Scatter_Plot](https://github.com/OmdenaAI/philadelphia-climate-change-buildings/blob/main/src/visualizations/task-2_eda_images/scatter_plot.png)

## 5) Hypothesis Testing
Hypothesis Testing is a method of verifying the validity of the experiment. It helps us in understanding whether the insights we gathered occured by chance. 
Here we make our hypothesis and see if this statistical testing accepts or rejects our hypothesis within the given confidence interval. With our data Hypothesis testing was not valid as data was not normally distributed and can make this testing baised because of outliers present in our data.

We have tried few Hypothesis testing method for the sake of our knowledge

5.1) Z-Test (Parametric test)

5.2) T-Test (Parametric test)

5.3) Chi-Square test (Parametric test)

5.4) Kruskal Wallis H-Test (Non- Parametric test)

We did two types of test
1) Parametric: Where mean is the best indicator of the data
2) Non-Parametric: Where median is the best indicator of the data

How to decide which test to choose?
1) Z-test when data is normally distributed and with large population size and known standard-deviation
2) T-test also known as student t-test, when population size is less than or equal to 30 and standard-deviation is unknown
3) Chi-square: Normally distributed data and also be used for understanding relation between categorical variables
4) Kruskal Wallis H-Test: It is non-parametric test and Population median of all groups are equal. It can be used to determine the statistical difference between two or more independent variables

